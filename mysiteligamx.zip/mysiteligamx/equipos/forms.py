from django import forms
from .models import Equipo

class EquipoForm(forms.ModelForm):
    class Meta:
        model = Equipo
        fields = ['nombre', 'año_creacion', 'dueño', 'campeonatos_ganados', 'ciudad_origen', 'color_equipacion']
        widgets = {
            'nombre': forms.TextInput(attrs={'placeholder': 'Nombre del Equipo'}),
            'año_creacion': forms.NumberInput(attrs={'placeholder': 'Año de creación'}),
            'dueño': forms.TextInput(attrs={'placeholder': 'Dueño'}),
            'campeonatos_ganados': forms.NumberInput(attrs={'placeholder': 'Campeonatos ganados'}),
            'ciudad_origen': forms.TextInput(attrs={'placeholder': 'Ciudad de origen'}),
            'color_equipacion': forms.TextInput(attrs={'placeholder': 'Color de equipación'}),
        }