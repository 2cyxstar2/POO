from django.urls import path
from . import views

urlpatterns = [
    path('', views.equipos_portada, name='equipos_portada'),
]