from django.db import models

class Equipo(models.Model):
    nombre = models.CharField(max_length=100, unique=True)
    año_creacion = models.PositiveIntegerField()
    dueño = models.CharField(max_length=100)
    campeonatos_ganados = models.PositiveIntegerField(default=0)
    ciudad_origen = models.CharField(max_length=100)
    color_equipacion = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.nombre} ({self.ciudad_origen})"
    
    class Meta:
        verbose_name_plural = "Equipos"

# Create your models here.
