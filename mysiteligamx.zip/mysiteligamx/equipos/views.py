from django.shortcuts import render, redirect
from .models import Equipo
from .forms import EquipoForm

def equipos_portada(request):
    if request.method == 'POST':
        form = EquipoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('equipos_portada')
    else:
        form = EquipoForm()
    
    equipos = Equipo.objects.all()
    return render(request, 'equipos/equipos.html', {
        'form': form,
        'equipos': equipos
    })