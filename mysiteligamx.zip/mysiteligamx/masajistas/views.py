from django.shortcuts import render, redirect
from .models import Masajista
from .forms import MasajistaForm  

def masajistas_portada(request):
    if request.method == 'POST':
        form = MasajistaForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('masajistas_portada')
    else:
        form = MasajistaForm()
    
    masajistas = Masajista.objects.all()
    return render(request, 'masajistas/masajistas.html', {
        'form': form,
        'masajistas': masajistas
    })