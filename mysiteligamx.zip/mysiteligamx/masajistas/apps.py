from django.apps import AppConfig


class MasajistasConfig(AppConfig):
    name = 'masajistas'
