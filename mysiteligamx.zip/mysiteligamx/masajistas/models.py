from django.db import models

from django.db import models

class Masajista(models.Model):
    nombre = models.CharField(max_length=100)
    apellido = models.CharField(max_length=100)
    edad = models.PositiveIntegerField()
    titulacion = models.CharField(max_length=100)
    años_experiencia = models.PositiveIntegerField()

    def __str__(self):
        return f"{self.nombre} {self.apellido} - {self.titulacion}"
    
    class Meta:
        verbose_name_plural = "Masajistas"
# Create your models here.
