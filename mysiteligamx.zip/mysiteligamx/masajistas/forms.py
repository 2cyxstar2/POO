from django import forms
from .models import Masajista

class MasajistaForm(forms.ModelForm):
    class Meta:
        model = Masajista
        fields = ['nombre', 'apellido', 'edad', 'titulacion', 'años_experiencia']
        widgets = {
            'nombre': forms.TextInput(attrs={'placeholder': 'Nombre'}),
            'apellido': forms.TextInput(attrs={'placeholder': 'Apellido'}),
            'edad': forms.NumberInput(attrs={'placeholder': 'Edad'}),
            'titulacion': forms.TextInput(attrs={'placeholder': 'Titulación (ej: Fisioterapia)'}),
            'años_experiencia': forms.NumberInput(attrs={'placeholder': 'Años de experiencia'}),
        }