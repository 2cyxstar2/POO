from django.urls import path
from . import views

urlpatterns = [
    path('', views.masajistas_portada, name='masajistas_portada'),
]