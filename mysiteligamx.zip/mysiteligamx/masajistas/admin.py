from django.contrib import admin
from .models import Masajista

admin.site.register(Masajista)

# Register your models here.
