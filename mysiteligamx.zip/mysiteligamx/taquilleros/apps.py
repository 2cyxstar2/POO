from django.apps import AppConfig


class TaquillerosConfig(AppConfig):
    name = 'taquilleros'
