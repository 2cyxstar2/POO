from django.urls import path
from . import views

urlpatterns = [
    path('', views.taquilleros_portada, name='taquilleros_portada'),
]