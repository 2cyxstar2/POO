from django.contrib import admin
from .models import Taquillero

admin.site.register(Taquillero)

# Register your models here.
