from django import forms
from .models import Taquillero

class TaquilleroForm(forms.ModelForm):
    class Meta:
        model = Taquillero
        fields = ['nombre', 'apellido', 'salario', 'horario_dias_trabajo', 'cantidad_boletos_vender']
        widgets = {
            'nombre': forms.TextInput(attrs={'placeholder': 'Nombre'}),
            'apellido': forms.TextInput(attrs={'placeholder': 'Apellido'}),
            'salario': forms.NumberInput(attrs={'placeholder': 'Salario'}),
            'horario_dias_trabajo': forms.TextInput(attrs={'placeholder': 'Horario y días (ej: 9am-5pm L-V)'}),
            'cantidad_boletos_vender': forms.NumberInput(attrs={'placeholder': 'Cantidad de boletos a vender'}),
        }