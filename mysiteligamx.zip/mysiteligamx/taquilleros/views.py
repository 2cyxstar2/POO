from django.shortcuts import render, redirect
from .models import Taquillero
from .forms import TaquilleroForm

def taquilleros_portada(request):
    if request.method == 'POST':
        form = TaquilleroForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('taquilleros_portada')
    else:
        form = TaquilleroForm()
    
    taquilleros = Taquillero.objects.all()
    return render(request, 'taquilleros/taquilleros.html', {
        'form': form,
        'taquilleros': taquilleros
    })