from django.db import models

class Taquillero(models.Model):
    nombre = models.CharField(max_length=100)
    apellido = models.CharField(max_length=100)
    salario = models.DecimalField(max_digits=10, decimal_places=2)
    horario_dias_trabajo = models.CharField(max_length=100)
    cantidad_boletos_vender = models.PositiveIntegerField(default=0)

    def __str__(self):
        return f"{self.nombre} {self.apellido}"
    
    class Meta:
        verbose_name_plural = "Taquilleros"

# Create your models here.
