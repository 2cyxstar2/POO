from django.shortcuts import render, redirect
from .models import Entrenador
from .forms import EntrenadorForm

def entrenadores_portada(request):
    if request.method == 'POST':
        form = EntrenadorForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('entrenadores_portada')
    else:
        form = EntrenadorForm()
    
    entrenadores = Entrenador.objects.all()
    return render(request, 'entrenadores/entrenadores.html', {
        'form': form,
        'entrenadores': entrenadores
    })