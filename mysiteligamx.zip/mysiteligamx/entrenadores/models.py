from django.db import models

class Entrenador(models.Model):
    id_federacion = models.CharField(max_length=50, unique=True)
    nombre = models.CharField(max_length=100)
    apellido = models.CharField(max_length=100)
    edad = models.PositiveIntegerField()
    años_experiencia = models.PositiveIntegerField()

    def __str__(self):
        return f"{self.nombre} {self.apellido} (ID: {self.id_federacion})"
    
    class Meta:
        verbose_name_plural = "Entrenadores"
        
# Create your models here.
