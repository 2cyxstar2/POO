from django import forms
from .models import Entrenador

class EntrenadorForm(forms.ModelForm):
    class Meta:
        model = Entrenador
        fields = ['id_federacion', 'nombre', 'apellido', 'edad', 'años_experiencia']
        widgets = {
            'id_federacion': forms.TextInput(attrs={'placeholder': 'ID Federación'}),
            'nombre': forms.TextInput(attrs={'placeholder': 'Nombre'}),
            'apellido': forms.TextInput(attrs={'placeholder': 'Apellido'}),
            'edad': forms.NumberInput(attrs={'placeholder': 'Edad'}),
            'años_experiencia': forms.NumberInput(attrs={'placeholder': 'Años de experiencia'}),
        }