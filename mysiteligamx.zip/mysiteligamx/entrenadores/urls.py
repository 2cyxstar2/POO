from django.urls import path
from . import views

urlpatterns = [
    path('', views.entrenadores_portada, name='entrenadores_portada'),
]