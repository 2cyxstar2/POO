from django.shortcuts import render, redirect
from .models import Futbolista
from .forms import FutbolistaForm

def futbolistas_portada(request):
    if request.method == 'POST':
        form = FutbolistaForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('futbolistas_portada')
    else:
        form = FutbolistaForm()
    
    futbolistas = Futbolista.objects.all()
    return render(request, 'futbolistas/futbolistas.html', {
        'form': form,
        'futbolistas': futbolistas
    })