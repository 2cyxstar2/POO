from django.urls import path
from . import views

urlpatterns = [
    path('', views.futbolistas_portada, name='futbolistas_portada'),
]