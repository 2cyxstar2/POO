from django.apps import AppConfig


class FutbolistasConfig(AppConfig):
    name = 'futbolistas'
