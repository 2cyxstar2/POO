from django.db import models

class Futbolista(models.Model):
    nombre = models.CharField(max_length=100)
    apellido = models.CharField(max_length=100)
    edad = models.PositiveIntegerField()
    dorsal = models.PositiveIntegerField(unique=True)
    posicion = models.CharField(max_length=50)

    def __str__(self):
        return f"{self.nombre} {self.apellido} - #{self.dorsal} ({self.posicion})"
    
    class Meta:
        verbose_name_plural = "Futbolistas"

# Create your models here.
