from django import forms
from .models import Futbolista

class FutbolistaForm(forms.ModelForm):
    class Meta:
        model = Futbolista
        fields = ['nombre', 'apellido', 'edad', 'dorsal', 'posicion']
        widgets = {
            'nombre': forms.TextInput(attrs={'placeholder': 'Nombre'}),
            'apellido': forms.TextInput(attrs={'placeholder': 'Apellido'}),
            'edad': forms.NumberInput(attrs={'placeholder': 'Edad'}),
            'dorsal': forms.NumberInput(attrs={'placeholder': 'Dorsal'}),
            'posicion': forms.TextInput(attrs={'placeholder': 'Posición (Delantero, Defensa, etc.)'}),
        }