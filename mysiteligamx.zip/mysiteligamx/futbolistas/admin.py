from django.contrib import admin
from .models import Futbolista

admin.site.register(Futbolista)

# Register your models here.
